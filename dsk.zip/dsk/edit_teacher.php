<?php
include_once '../../auth/session.php';
if ($_SESSION['role'] !== 'admin') {
    header("Location: ../../login.html");
    exit;
}
require '../../auth/db.php';

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ?");
$stmt->execute([$id]);
$teacher = $stmt->fetch();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $class = $_POST['class'];
    $joining = $_POST['joining_date'];
    $salary = $_POST['salary'];

    if (!empty($_FILES['photo']['name'])) {
        $photo = $_FILES['photo']['name'];
        $target = "../../uploads/" . basename($photo);
        move_uploaded_file($_FILES['photo']['tmp_name'], $target);
        $stmt = $pdo->prepare("UPDATE teachers SET name=?, email=?, class=?, joining_date=?, salary=?, photo=? WHERE id=?");
        $stmt->execute([$name, $email, $class, $joining, $salary, $photo, $id]);
    } else {
        $stmt = $pdo->prepare("UPDATE teachers SET name=?, email=?, class=?, joining_date=?, salary=? WHERE id=?");
        $stmt->execute([$name, $email, $class, $joining, $salary, $id]);
    }
    header("Location: view_teachers.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Edit Teacher</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
  <h1 class="text-2xl font-bold mb-4">Edit Teacher</h1>
  <form method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow w-full max-w-md">
    <input name="name" value="<?= $teacher['name'] ?>" class="w-full p-2 border rounded mb-4" required>
    <input name="email" value="<?= $teacher['email'] ?>" type="email" class="w-full p-2 border rounded mb-4" required>
    <input name="class" value="<?= $teacher['class'] ?>" class="w-full p-2 border rounded mb-4" required>
    <input name="joining_date" type="date" value="<?= $teacher['joining_date'] ?>" class="w-full p-2 border rounded mb-4" required>
    <input name="salary" type="number" value="<?= $teacher['salary'] ?>" class="w-full p-2 border rounded mb-4" required>
    <input name="photo" type="file" class="w-full p-2 border rounded mb-4">
    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Update</button>
  </form>
</body>
</html>

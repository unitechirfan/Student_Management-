<?php
include_once '../../auth/session.php';
if ($_SESSION['role'] !== 'admin') {
    header("Location: ../../login.html");
    exit;
}
require '../../auth/db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $class = $_POST['class'];
    $joining = $_POST['joining_date'];
    $salary = $_POST['salary'];

    $photo = $_FILES['photo']['name'];
    $target = "../../uploads/" . basename($photo);
    move_uploaded_file($_FILES['photo']['tmp_name'], $target);

    $stmt = $pdo->prepare("INSERT INTO teachers (name, email, class, joining_date, salary, photo) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $email, $class, $joining, $salary, $photo]);
    header("Location: view_teachers.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Add Teacher</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
  <h1 class="text-2xl font-bold mb-4">Add Teacher</h1>
  <form method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow w-full max-w-md">
    <input name="name" placeholder="Name" class="w-full p-2 border rounded mb-4" required>
    <input name="email" type="email" placeholder="Email" class="w-full p-2 border rounded mb-4" required>
    <input name="class" placeholder="Class" class="w-full p-2 border rounded mb-4" required>
    <input name="joining_date" type="date" class="w-full p-2 border rounded mb-4" required>
    <input name="salary" type="number" placeholder="Salary (₹)" class="w-full p-2 border rounded mb-4" required>
    <input name="photo" type="file" class="w-full p-2 border rounded mb-4" required>
    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Add Teacher</button>
  </form>
</body>
</html>

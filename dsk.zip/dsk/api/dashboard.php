<?php
require '../includes/db.php';

$students = $conn->query("SELECT COUNT(*) FROM students")->fetch_row()[0];
$teachers = $conn->query("SELECT COUNT(*) FROM teachers")->fetch_row()[0];
echo json_encode(['total_students' => $students, 'total_teachers' => $teachers]);
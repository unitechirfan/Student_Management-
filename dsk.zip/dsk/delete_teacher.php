<?php
include_once '../../auth/session.php';
if ($_SESSION['role'] !== 'admin') {
    header("Location: ../../login.html");
    exit;
}
require '../../auth/db.php';

$id = $_GET['id'];
$stmt = $pdo->prepare("DELETE FROM teachers WHERE id = ?");
$stmt->execute([$id]);
header("Location: view_teachers.php");
exit;
?>

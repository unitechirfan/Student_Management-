<?php
require 'db.php';

// Total students
$stmt = $pdo->query("SELECT COUNT(*) AS total_students FROM students");
$students = $stmt->fetch();

// Total teachers
$stmt = $pdo->query("SELECT COUNT(*) AS total_teachers FROM teachers");
$teachers = $stmt->fetch();

echo json_encode([
    'students' => $students['total_students'],
    'teachers' => $teachers['total_teachers']
]);
?>

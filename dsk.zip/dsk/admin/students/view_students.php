<?php
include_once '../../auth/session.php';
if ($_SESSION['role'] !== 'admin') {
    header("Location: ../../login.html");
    exit;
}
require '../../auth/db.php';
$stmt = $pdo->query("SELECT * FROM students");
$students = $stmt->fetchAll();
?>
<?php if ($_SESSION['role'] === 'admin'): ?>
  <!-- export buttons here -->
<?php endif; ?>

<!DOCTYPE html>
<html>
<head>
  <title>View Students</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
  <h1 class="text-2xl font-bold mb-4">All Students</h1>
  <a href="add_student.php" class="bg-blue-600 text-white px-4 py-2 rounded">Add Student</a>
  <div class="mb-4 space-x-2">
  <button onclick="exportPDF()" class="bg-red-600 text-white px-4 py-2 rounded">Export PDF</button>
  <button onclick="exportExcel()" class="bg-green-600 text-white px-4 py-2 rounded">Export Excel</button>
</div>

  <table class="table-auto w-full mt-4 bg-white shadow rounded">
    <thead>
      <tr>
        <th class="px-4 py-2">Photo</th>
        <th class="px-4 py-2">Name</th>
        <th class="px-4 py-2">Email</th>
        <th class="px-4 py-2">Class</th>
        <th class="px-4 py-2">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($students as $student): ?>
      <tr class="border-t">
        <td class="px-4 py-2"><img src="../../uploads/<?= $student['photo'] ?>" class="w-12 h-12 rounded-full"></td>
        <td class="px-4 py-2"><?= htmlspecialchars($student['name']) ?></td>
        <td class="px-4 py-2"><?= htmlspecialchars($student['email']) ?></td>
        <td class="px-4 py-2"><?= htmlspecialchars($student['class']) ?></td>
        <td class="px-4 py-2">
          <a href="edit_student.php?id=<?= $student['id'] ?>" class="text-blue-500">Edit</a> |
          <a href="delete_student.php?id=<?= $student['id'] ?>" class="text-red-500" onclick="return confirm('Are you sure?')">Delete</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
function exportExcel() {
    const table = document.querySelector("table");
    const wb = XLSX.utils.table_to_book(table, { sheet: "Sheet 1" });
    XLSX.writeFile(wb, "data_export.xlsx");
}

function exportPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('l', 'pt', 'a4');
    const table = document.querySelector("table");

    html2canvas(table).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const imgProps = doc.getImageProperties(imgData);
        const pdfWidth = doc.internal.pageSize.getWidth();
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

        doc.addImage(imgData, 'PNG', 20, 20, pdfWidth - 40, pdfHeight);
        doc.save("data_export.pdf");
    });
}
</script>

</body>
</html>

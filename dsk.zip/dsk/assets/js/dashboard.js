document.addEventListener('DOMContentLoaded', () => {
  fetch('backend/getCounts.php')
    .then(response => response.json())
    .then(data => {
      document.getElementById('student-count').textContent = data.students;
      document.getElementById('teacher-count').textContent = data.teachers;
    })
    .catch(error => {
      console.error('Error fetching counts:', error);
    });
});

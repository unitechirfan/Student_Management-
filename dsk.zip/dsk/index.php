<?php
require 'includes/auth.php';
include 'views/dashboard.php';
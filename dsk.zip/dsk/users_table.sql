CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE,
  password VARCHAR(255),
  role ENUM('admin', 'teacher') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert a default admin user
INSERT INTO users (username, password, role) VALUES (
  'admin',
  '$2b$12$35NFjmyxDhHyIvlr7RdDI.cxJi/eVOF/VM38HdeHRKeQTqKMBi5Ha',
  'admin'
);

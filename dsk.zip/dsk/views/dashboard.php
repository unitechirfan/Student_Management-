<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <link href="/assets/css/style.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-dark bg-dark p-3">
  <span class="navbar-brand">Student Management</span>
  <a href="/logout.php" class="btn btn-danger">Logout</a>
</nav>
<div class="container mt-4">
  <div class="row">
    <div class="col-md-6">
      <div class="card text-bg-primary">
        <div class="card-body">
          <h5>Total Students (This Month)</h5>
          <p class="display-6" id="totalStudents">0</p>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card text-bg-success">
        <div class="card-body">
          <h5>Total Teachers (This Month)</h5>
          <p class="display-6" id="totalTeachers">0</p>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="/assets/js/dashboard.js"></script>
</body>
</html>
<?php
include_once '../../auth/session.php';
if ($_SESSION['role'] !== 'admin') {
    header("Location: ../../login.html");
    exit;
}
require '../../auth/db.php';

$id = $_GET['id'];
$stmt = $pdo->prepare("DELETE FROM students WHERE id = ?");
$stmt->execute([$id]);
header("Location: view_students.php");
exit;
?>

<?php
include_once '../../auth/session.php';
if ($_SESSION['role'] !== 'admin') {
    header("Location: ../../login.html");
    exit;
}
require '../../auth/db.php';
$teachers = $pdo->query("SELECT * FROM teachers")->fetchAll();
?>
<?php if ($_SESSION['role'] === 'admin'): ?>
  <!-- export buttons here -->
<?php endif; ?>

<!DOCTYPE html>
<html>
<head>
  <title>Teachers</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
  <div class="flex justify-between items-center mb-4">
    <h1 class="text-2xl font-bold">All Teachers</h1>
    <a href="add_teacher.php" class="bg-green-600 text-white px-4 py-2 rounded">Add Teacher</a>
  </div>
  <div class="mb-4 space-x-2">
  <button onclick="exportPDF()" class="bg-red-600 text-white px-4 py-2 rounded">Export PDF</button>
  <button onclick="exportExcel()" class="bg-green-600 text-white px-4 py-2 rounded">Export Excel</button>
</div>

  <table class="w-full bg-white rounded shadow">
    <thead>
      <tr class="bg-gray-200 text-left">
        <th class="p-3">Photo</th>
        <th class="p-3">Name</th>
        <th class="p-3">Email</th>
        <th class="p-3">Class</th>
        <th class="p-3">Joining Date</th>
        <th class="p-3">Salary</th>
        <th class="p-3">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($teachers as $t): ?>
      <tr class="border-t">
        <td class="p-3"><img src="../../uploads/<?= $t['photo'] ?>" width="50"></td>
        <td class="p-3"><?= $t['name'] ?></td>
        <td class="p-3"><?= $t['email'] ?></td>
        <td class="p-3"><?= $t['class'] ?></td>
        <td class="p-3"><?= $t['joining_date'] ?></td>
        <td class="p-3">₹<?= $t['salary'] ?></td>
        <td class="p-3">
          <a href="edit_teacher.php?id=<?= $t['id'] ?>" class="text-blue-600">Edit</a> |
          <a href="delete_teacher.php?id=<?= $t['id'] ?>" class="text-red-600">Delete</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
function exportExcel() {
    const table = document.querySelector("table");
    const wb = XLSX.utils.table_to_book(table, { sheet: "Sheet 1" });
    XLSX.writeFile(wb, "data_export.xlsx");
}

function exportPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('l', 'pt', 'a4');
    const table = document.querySelector("table");

    html2canvas(table).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const imgProps = doc.getImageProperties(imgData);
        const pdfWidth = doc.internal.pageSize.getWidth();
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

        doc.addImage(imgData, 'PNG', 20, 20, pdfWidth - 40, pdfHeight);
        doc.save("data_export.pdf");
    });
}
</script>

</body>
</html>
